"""
Pythonproj_maddy17.

An example python script.
"""

__version__ = "0.1.0"
__author__ = 'Maathavan Manimaran'
__credits__ = 'SG Innovate'