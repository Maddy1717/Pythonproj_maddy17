print ("Hello World")
print ("Goodbye World")
